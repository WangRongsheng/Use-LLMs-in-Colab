#!/bin/bash
argument="--continuous"
./run.sh "$argument"
